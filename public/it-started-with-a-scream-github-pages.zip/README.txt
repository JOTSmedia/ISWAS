GitHub Pages for https://jotsmedia.github.io/iswas/

Upload the CONTENTS of this folder to the root of the jotsmedia/iswas repository
(or the root of its gh-pages branch). Do not put them inside another iswas folder.
